"use client";

export default function Skeleton({ className = "" }) {
    return (
        <div
            className={`animate-pulse rounded-xl bg-zinc-100 ${className}`}
            aria-hidden="true"
        />
    );
}